#!/bin/bash
# Full experiment pipeline. Edit STEPS and SEEDS to fit your compute budget.
# Run from the project root:  bash run_all.sh
set -e
STEPS=${STEPS:-1000000}
SEEDS=${SEEDS:-"0 1 2"}
LAYOUT=${LAYOUT:-compact_v1}
AGENTS=${AGENTS:-4}
DEVICE=${DEVICE:-cpu}      # use cuda on Colab if you switched the runtime to GPU

# 1. non learning baselines (fast)
python -m wmarl.evaluate --policy random --layout $LAYOUT --agents $AGENTS --episodes 30 --out results/random
python -m wmarl.evaluate --policy greedy --layout $LAYOUT --agents $AGENTS --episodes 30 --out results/greedy

# 2. single agent PPO sanity baseline (1 robot, 1 request)
python -m wmarl.train --algo ppo --queue 1 --steps 300000 --seed 0 --device $DEVICE --name ppo_single_s0

# 3. the three multi agent algorithms, several seeds
for s in $SEEDS; do
  python -m wmarl.train --algo ippo  --layout $LAYOUT --agents $AGENTS --steps $STEPS --seed $s --device $DEVICE --name ippo_s$s
  python -m wmarl.train --algo mappo --layout $LAYOUT --agents $AGENTS --steps $STEPS --seed $s --device $DEVICE --name mappo_s$s
  python -m wmarl.train --algo qmix  --layout $LAYOUT --agents $AGENTS --steps $STEPS --seed $s --device $DEVICE --name qmix_s$s
done

# 4. monitoring demo and dashboard
python -m wmarl.drift_demo --out results/drift
python -m wmarl.dashboard --out dashboard.html
echo "Open dashboard.html in a browser."
