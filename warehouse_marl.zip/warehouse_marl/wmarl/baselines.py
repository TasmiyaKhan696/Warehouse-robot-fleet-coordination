"""Random and greedy (rule based) baselines. Greedy uses BFS path planning and a simple
unique target assignment, so it is a fair non-learning reference."""
import numpy as np
from rware.warehouse import Action
from . import nav


class RandomPolicy:
    name = "random"

    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)

    def reset(self):
        pass

    def act(self, env, obs):
        return self.rng.integers(0, env.n_actions, size=env.n_agents)


class GreedyPolicy:
    name = "greedy"

    def reset(self):
        pass

    def act(self, env, obs):
        u = env.u
        tgt, stage, _ = nav.targets_and_potentials(u, claimed_unique=True, delivered=env._delivered)
        occupied = {(a.x, a.y) for a in u.agents}
        acts = []
        for i, a in enumerate(u.agents):
            here = (a.x, a.y)
            t = (int(tgt[i, 0]), int(tgt[i, 1]))
            others = occupied - {here}
            st = stage[i]
            if st == nav.STAGE_SEEK:
                if here == t and any(s.x == a.x and s.y == a.y for s in nav.free_requests(u)):
                    acts.append(Action.TOGGLE_LOAD.value)
                elif t == here:
                    acts.append(Action.NOOP.value)
                else:
                    acts.append(nav.action_towards(u, a, t, others))
            elif st == nav.STAGE_DELIVER:
                acts.append(nav.action_towards(u, a, t, others))
            else:
                if not u.highways[a.y, a.x]:
                    acts.append(Action.TOGGLE_LOAD.value)
                else:
                    acts.append(nav.action_towards(u, a, t, others))
        return np.array(acts)
