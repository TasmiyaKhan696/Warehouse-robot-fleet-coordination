"""Navigation helpers shared by the environment wrapper (shaping, extra observations)
and the greedy baseline. All functions read the raw rware Warehouse object `u`."""
from collections import deque
import numpy as np
from rware.warehouse import Action, Direction, _LAYER_SHELFS

STAGE_SEEK, STAGE_DELIVER, STAGE_RETURN = 0, 1, 2
_DELTA = {Direction.UP: (0, -1), Direction.DOWN: (0, 1),
          Direction.LEFT: (-1, 0), Direction.RIGHT: (1, 0)}
_WRAP = [Direction.UP, Direction.RIGHT, Direction.DOWN, Direction.LEFT]


def stage_of(u, a, delivered=False):
    """SEEK: looking for a requested shelf (also while holding a shelf nobody asked for).
    DELIVER: carrying a requested shelf. RETURN: carrying a shelf this robot just delivered."""
    if a.carrying_shelf is None:
        return STAGE_SEEK
    if a.carrying_shelf in u.request_queue:
        return STAGE_DELIVER
    return STAGE_RETURN if delivered else STAGE_SEEK


def empty_slots(u):
    """Shelf cells (non-highway) that currently hold no shelf, as (k,2) array of (x,y)."""
    mask = (u.highways == 0) & (u.grid[_LAYER_SHELFS] == 0)
    ys, xs = np.nonzero(mask)
    return np.stack([xs, ys], 1) if len(xs) else np.zeros((0, 2), dtype=int)


def free_requests(u):
    """Requested shelves that nobody is carrying, as list of Shelf objects."""
    carried = {a.carrying_shelf.id for a in u.agents if a.carrying_shelf is not None}
    return [s for s in u.request_queue if s.id not in carried]


def _d(p, Q):
    return np.abs(Q - p).sum(-1)


def targets_and_potentials(u, claimed_unique=False, delivered=None):
    """For every agent return (target_xy (n,2), stage (n,), potential (n,)).
    Potential is minus the estimated remaining path length of the whole pick, deliver,
    return cycle (Manhattan distances). It is continuous across stage changes, so reward
    shaping built from it cannot be farmed by repeated pick up and drop."""
    G = np.array(u.goals, dtype=int)
    S = empty_slots(u)
    R_objs = free_requests(u)
    R = np.array([[s.x, s.y] for s in R_objs], dtype=int) if R_objs else np.zeros((0, 2), int)
    if len(S):
        dgs = np.array([_d(g, S).min() for g in G], dtype=float)
    else:
        dgs = np.zeros(len(G))
    n = len(u.agents)
    tgt = np.zeros((n, 2), dtype=int)
    stage = np.zeros(n, dtype=int)
    phi = np.zeros(n)
    taken = set()
    for i, a in enumerate(u.agents):
        p = np.array([a.x, a.y])
        st = stage_of(u, a, bool(delivered[i]) if delivered is not None else False)
        stage[i] = st
        tgt[i] = p
        if st == STAGE_SEEK:
            if len(R):
                dr = _d(p, R).astype(float)
                if claimed_unique:
                    for j in taken:
                        dr[j] = 1e9
                j = int(np.argmin(dr))
                if dr[j] < 1e9:
                    taken.add(j)
                    tgt[i] = R[j]
                    to_goal = min(_d(R[j], G[k]) + dgs[k] for k in range(len(G)))
                    phi[i] = -(dr[j] + to_goal)
        elif st == STAGE_DELIVER:
            costs = [_d(p, G[k]) + dgs[k] for k in range(len(G))]
            k = int(np.argmin(costs))
            tgt[i] = G[k]
            phi[i] = -costs[k]
        else:
            if len(S):
                ds = _d(p, S)
                j = int(np.argmin(ds))
                tgt[i] = S[j]
                phi[i] = -ds[j]
    return tgt, stage, phi


def _bfs_next_cell(u, a, goal_xy, blocked_cells):
    h, w = u.grid_size
    start = (a.x, a.y)
    goal = (int(goal_xy[0]), int(goal_xy[1]))
    if start == goal:
        return None
    loaded = a.carrying_shelf is not None
    shelf_layer = u.grid[_LAYER_SHELFS]
    prev = {start: None}
    dq = deque([start])
    while dq:
        c = dq.popleft()
        if c == goal:
            break
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            nx, ny = c[0] + dx, c[1] + dy
            nb = (nx, ny)
            if not (0 <= nx < w and 0 <= ny < h) or nb in prev:
                continue
            if loaded and shelf_layer[ny, nx] != 0:
                continue
            if nb in blocked_cells and nb != goal:
                continue
            prev[nb] = c
            dq.append(nb)
    if goal not in prev:
        return None
    c = goal
    while prev[c] != start:
        c = prev[c]
    return c


def action_towards(u, a, goal_xy, blocked_cells=()):
    """One primitive action that moves agent `a` toward goal_xy along a BFS path."""
    nxt = _bfs_next_cell(u, a, goal_xy, set(blocked_cells))
    if nxt is None:
        nxt = _bfs_next_cell(u, a, goal_xy, set())
    if nxt is None:
        return Action.NOOP.value
    want = {v: k for k, v in _DELTA.items()}[(nxt[0] - a.x, nxt[1] - a.y)]
    if want == a.dir:
        return Action.FORWARD.value
    diff = (_WRAP.index(want) - _WRAP.index(a.dir)) % 4
    return Action.RIGHT.value if diff in (1, 2) else Action.LEFT.value
