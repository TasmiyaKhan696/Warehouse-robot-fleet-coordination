"""Train a policy. Examples:
  python -m wmarl.train --algo ppo   --steps 300000 --seed 0     # single agent PPO baseline
  python -m wmarl.train --algo ippo  --steps 1000000 --seed 0
  python -m wmarl.train --algo mappo --steps 1000000 --seed 0
  python -m wmarl.train --algo qmix  --steps 1000000 --seed 0
"""
import argparse, csv, json
from dataclasses import asdict
from pathlib import Path
import torch
from .env import EnvConfig
from .evaluate import evaluate_policy, save_eval, summarize, load_policy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--algo", choices=["ppo", "ippo", "mappo", "qmix"], required=True)
    ap.add_argument("--layout", default="compact_v1")
    ap.add_argument("--agents", type=int, default=4)
    ap.add_argument("--queue", type=int, default=0)
    ap.add_argument("--steps", type=int, default=500_000)
    ap.add_argument("--envs", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--shaping", type=float, default=0.1)
    ap.add_argument("--stage-bonus", type=float, default=0.5)
    ap.add_argument("--collision-penalty", type=float, default=0.1)
    ap.add_argument("--no-extra-obs", action="store_true")
    ap.add_argument("--no-procs", action="store_true", help="run envs in the main process")
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--device", default="cpu", help="cpu or cuda")
    ap.add_argument("--name", default=None)
    ap.add_argument("--eval-episodes", type=int, default=30)
    a = ap.parse_args()

    n_agents = 1 if a.algo == "ppo" else a.agents
    cfg = EnvConfig(layout=a.layout, n_agents=n_agents, request_queue_size=a.queue,
                    shaping=a.shaping, stage_bonus=a.stage_bonus, collision_penalty=a.collision_penalty,
                    extra_obs=not a.no_extra_obs)
    name = a.name or f"{a.algo}_{a.layout}_{n_agents}ag_s{a.seed}"
    out = Path("runs") / name
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(json.dumps(dict(args=vars(a), env=asdict(cfg)), indent=2))
    procs = not a.no_procs

    if a.algo == "qmix":
        from .qmix import train_qmix
        model, meta, hist = train_qmix(cfg, a.steps, a.envs, a.seed, lr=a.lr or 5e-4,
                                       procs=procs, device=a.device)
    else:
        from .ppo import train_ppo
        model, meta, hist = train_ppo(cfg, a.algo, a.steps, a.envs, seed=a.seed, lr=a.lr or 3e-4,
                                      procs=procs, device=a.device)
    model = model.to("cpu")
    torch.save(dict(state_dict=model.state_dict(), meta=meta, cfg=asdict(cfg)), out / "model.pt")
    if hist:
        with open(out / "train_log.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=sorted({k for h in hist for k in h}))
            w.writeheader()
            w.writerows(hist)
    pol, cfg = load_policy(out)
    rows = evaluate_policy(pol, cfg, a.eval_episodes)
    save_eval(rows, out)
    print("final eval:", {k: round(v["mean"], 2) for k, v in summarize(rows).items()})


if __name__ == "__main__":
    main()
