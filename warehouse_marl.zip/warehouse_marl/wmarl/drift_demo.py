"""Run a policy over a stream whose conditions change, and log what the monitor detects.
Uses the greedy policy by default because it works for any layout and fleet size
(a trained network is tied to the fleet size and layout it was trained on).
  python -m wmarl.drift_demo --out results/drift
"""
import argparse, csv, json
from pathlib import Path
from .env import EnvConfig
from .baselines import GreedyPolicy
from .evaluate import evaluate_policy
from .monitor import DriftMonitor

# (name, layout, agents, actual queue, queue the monitor is told about, episodes)
# The hidden phase changes demand without telling the monitor, so only the KPI stream reveals it.
PHASES = [
    ("normal", "compact_v1", 4, 4, 4, 25),
    ("hidden_demand_drop", "compact_v1", 4, 1, 4, 20),
    ("fleet_and_layout_change", "wide_v1", 8, 8, 8, 15),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/drift")
    ap.add_argument("--threshold", type=float, default=9.0, help="KPI floor (throughput per 100 steps)")
    a = ap.parse_args()
    mon = DriftMonitor(kpi_threshold=a.threshold)
    rows, ep = [], 0
    for name, layout, n, q, q_reported, eps in PHASES:
        cfg = EnvConfig(layout=layout, n_agents=n, request_queue_size=q)
        for r in evaluate_policy(GreedyPolicy(), cfg, eps, seed0=50_000 + ep):
            alerts = mon.update(ep, r, dict(layout=layout, n_agents=n, queue=q_reported))
            rows.append(dict(episode=ep, phase=name, layout=layout, n_agents=n, queue=q,
                             throughput=r["throughput"], collision_rate=r["collision_rate"],
                             utilization=r["utilization"], alerts=";".join(x["type"] for x in alerts)))
            ep += 1
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "drift_log.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    (out / "alerts.json").write_text(json.dumps(mon.alerts, indent=2))
    for al in mon.alerts:
        print(al)


if __name__ == "__main__":
    main()
