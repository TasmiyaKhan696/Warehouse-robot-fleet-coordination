"""Render a live demo or save a GIF. Headless machines (Colab) need a virtual display:
  xvfb-run -a python -m wmarl.demo --policy greedy --gif demo_greedy.gif
  xvfb-run -a python -m wmarl.demo --policy run:runs/<name> --gif demo_trained.gif
On a laptop with a screen, add --window to open the viewer instead of saving a GIF."""
import argparse, time
from PIL import Image
from .env import WarehouseMARL, EnvConfig
from .baselines import RandomPolicy, GreedyPolicy
from .evaluate import load_policy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", default="greedy")
    ap.add_argument("--layout", default="compact_v1")
    ap.add_argument("--agents", type=int, default=4)
    ap.add_argument("--steps", type=int, default=250)
    ap.add_argument("--skip", type=int, default=2, help="keep every n-th frame in the GIF")
    ap.add_argument("--gif", default="demo.gif")
    ap.add_argument("--window", action="store_true")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    cfg = EnvConfig(layout=a.layout, n_agents=a.agents)
    if a.policy == "random":
        pol = RandomPolicy(0)
    elif a.policy == "greedy":
        pol = GreedyPolicy()
    else:
        pol, cfg = load_policy(a.policy.split(":", 1)[1])
    env = WarehouseMARL(cfg, seed=a.seed)
    obs = env.reset(seed=a.seed)
    frames = []
    for t in range(a.steps):
        obs, _, done, _ = env.step(pol.act(env, obs))
        if a.window:
            env.u.render(mode="human")
            time.sleep(0.05)
        elif t % a.skip == 0:
            frames.append(Image.fromarray(env.render_rgb()))
        if done:
            break
    if not a.window:
        frames[0].save(a.gif, save_all=True, append_images=frames[1:], duration=80, loop=0)
        print("saved", a.gif, len(frames), "frames")
    print({k: round(v, 2) for k, v in env.episode_metrics().items()})


if __name__ == "__main__":
    main()
