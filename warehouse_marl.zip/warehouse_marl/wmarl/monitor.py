"""Monitoring: KPI threshold alerts, layout / fleet-size / demand configuration changes,
and sustained performance shifts (z-test of a rolling window against a reference window)."""
from collections import deque
import numpy as np


class DriftMonitor:
    def __init__(self, reference_episodes=15, window=5, z_limit=3.0, patience=3,
                 kpi_threshold=None, kpi="throughput"):
        self.ref_n, self.window, self.z_limit, self.patience = reference_episodes, window, z_limit, patience
        self.kpi_threshold, self.kpi = kpi_threshold, kpi
        self.cfg = None
        self._reset_reference()
        self.alerts = []
        self._below = False

    def _reset_reference(self):
        self.ref = []
        self.win = deque(maxlen=self.window)
        self.ref_mean = self.ref_std = None
        self.streak = 0
        self.shift_active = False

    def update(self, episode, kpis, cfg):
        """kpis: dict with at least the monitored KPI. cfg: dict(layout, n_agents, queue)."""
        new = []
        if self.cfg is not None and cfg != self.cfg:
            for key, label in (("layout", "layout_change"), ("n_agents", "fleet_size_change"),
                               ("queue", "demand_config_change")):
                if cfg[key] != self.cfg[key]:
                    new.append(dict(episode=episode, type=label,
                                    detail=f"{key}: {self.cfg[key]} -> {cfg[key]}"))
            self._reset_reference()          # re-baseline after a known change
            self._below = False
        self.cfg = dict(cfg)
        v = float(kpis[self.kpi])

        if self.ref_mean is None:
            self.ref.append(v)
            if len(self.ref) >= self.ref_n:
                self.ref_mean = float(np.mean(self.ref))
                self.ref_std = float(np.std(self.ref)) + 1e-6
        else:
            self.win.append(v)
            if len(self.win) == self.window:
                z = (np.mean(self.win) - self.ref_mean) / (self.ref_std / np.sqrt(self.window))
                self.streak = self.streak + 1 if abs(z) > self.z_limit else 0
                if self.streak >= self.patience and not self.shift_active:
                    self.shift_active = True
                    direction = "drop" if z < 0 else "rise"
                    new.append(dict(episode=episode, type="sustained_shift",
                                    detail=f"{self.kpi} {direction}, z={z:.1f}, "
                                           f"ref {self.ref_mean:.1f} -> now {np.mean(self.win):.1f}"))
                if self.streak == 0:
                    self.shift_active = False
        if self.kpi_threshold is not None and len(self.win) == self.window:
            below = np.mean(self.win) < self.kpi_threshold
            if below and not self._below:
                new.append(dict(episode=episode, type="kpi_below_threshold",
                                detail=f"{self.kpi} {np.mean(self.win):.1f} < {self.kpi_threshold}"))
            self._below = below
        self.alerts += new
        return new
