"""Evaluate random, greedy or a trained run on identical seeds and save per-episode metrics.
Examples:
  python -m wmarl.evaluate --policy random --episodes 30 --out results/random
  python -m wmarl.evaluate --policy greedy --episodes 30 --out results/greedy
  python -m wmarl.evaluate --policy run:runs/mappo_s0 --episodes 30 --out results/mappo_s0
"""
import argparse, csv, json
from dataclasses import asdict
from pathlib import Path
import numpy as np
import torch
from .env import WarehouseMARL, EnvConfig
from .baselines import RandomPolicy, GreedyPolicy

METRICS = ["deliveries", "throughput", "collisions", "collision_rate", "blocked_moves",
           "steps_per_delivery", "utilization", "carry_share", "efficiency"]


def evaluate_policy(policy, cfg: EnvConfig, episodes=30, seed0=10_000):
    env = WarehouseMARL(cfg, seed=seed0)
    rows = []
    for ep in range(episodes):
        obs = env.reset(seed=seed0 + ep)
        policy.reset()
        done = False
        while not done:
            obs, _, done, _ = env.step(policy.act(env, obs))
        m = env.episode_metrics()
        m.update(episode=ep, policy=policy.name, layout=cfg.layout, n_agents=cfg.n_agents,
                 queue=cfg.request_queue_size or cfg.n_agents)
        rows.append(m)
    env.close()
    return rows


def summarize(rows):
    out = {}
    for k in METRICS:
        v = np.array([r[k] for r in rows], dtype=float)
        out[k] = dict(mean=float(v.mean()), std=float(v.std()))
    return out


def save_eval(rows, out_dir):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    keys = ["policy", "layout", "n_agents", "queue", "episode"] + METRICS
    with open(out / "eval.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    (out / "summary.json").write_text(json.dumps(summarize(rows), indent=2))


def load_policy(run_dir, deterministic=False):
    from .ppo import ActorCritic, PPOPolicy
    from .qmix import AgentQ, QmixPolicy
    ck = torch.load(Path(run_dir) / "model.pt", map_location="cpu", weights_only=False)
    meta, cfg = ck["meta"], EnvConfig(**ck["cfg"])
    if meta["algo"] == "qmix":
        q = AgentQ(meta["n_agents"], meta["obs_dim"], meta["n_actions"])
        q.load_state_dict(ck["state_dict"])
        return QmixPolicy(q), cfg
    net = ActorCritic(meta["algo"], meta["n_agents"], meta["obs_dim"], meta["state_dim"], meta["n_actions"])
    net.load_state_dict(ck["state_dict"])
    return PPOPolicy(net, meta["algo"], deterministic), cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", required=True, help="random | greedy | run:<run_dir>")
    ap.add_argument("--layout", default="compact_v1")
    ap.add_argument("--agents", type=int, default=4)
    ap.add_argument("--queue", type=int, default=0)
    ap.add_argument("--episodes", type=int, default=30)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = EnvConfig(layout=a.layout, n_agents=a.agents, request_queue_size=a.queue)
    if a.policy == "random":
        pol = RandomPolicy(0)
    elif a.policy == "greedy":
        pol = GreedyPolicy()
    else:
        pol, cfg = load_policy(a.policy.split(":", 1)[1])
    rows = evaluate_policy(pol, cfg, a.episodes)
    save_eval(rows, a.out)
    for k, v in summarize(rows).items():
        print(f"{k:20s} {v['mean']:8.2f} +- {v['std']:.2f}")


if __name__ == "__main__":
    main()
