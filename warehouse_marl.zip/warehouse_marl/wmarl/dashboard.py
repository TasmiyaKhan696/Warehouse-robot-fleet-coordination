"""Build a single HTML dashboard from results/*/eval.csv, runs/*/eval.csv, runs/*/train_log.csv
and results/drift/{drift_log.csv,alerts.json}.
  python -m wmarl.dashboard --out dashboard.html
"""
import argparse, base64, csv, glob, io, json, os
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

KPIS = [("throughput", "Throughput (deliveries / 100 steps)"),
        ("collision_rate", "Collision rate (events / 100 steps)"),
        ("utilization", "Agent utilization (share of non idle steps)"),
        ("efficiency", "Coordination efficiency (deliveries / 100 active robot steps)"),
        ("steps_per_delivery", "Task completion time (steps per delivery)")]


def _png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def _read(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def label_of(path, rows):
    d = os.path.basename(os.path.dirname(path))
    return d


def collect():
    groups = defaultdict(list)
    for p in sorted(glob.glob("results/*/eval.csv") + glob.glob("runs/*/eval.csv")):
        if "probe" in p:
            continue
        rows = _read(p)
        if rows:
            groups[rows[0]["policy"]].extend(rows)
    return groups


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="dashboard.html")
    a = ap.parse_args()
    groups = collect()
    html = ["<html><head><meta charset='utf-8'><title>Warehouse fleet dashboard</title>",
            "<style>body{font-family:system-ui,sans-serif;max-width:980px;margin:24px auto;padding:0 12px;color:#222}",
            "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 8px;text-align:right}",
            "th:first-child,td:first-child{text-align:left}img{max-width:100%}h2{margin-top:32px}</style></head><body>",
            "<h1>Autonomous warehouse fleet: KPI dashboard</h1>",
            "<p>All numbers are simulation results on identical evaluation seeds. Mean and standard deviation over episodes (and seeds, when several runs share a method).</p>"]
    if groups:
        names = list(groups)
        html.append("<h2>KPI summary</h2><table><tr><th>Method</th><th>Episodes</th>" +
                    "".join(f"<th>{k}</th>" for k, _ in KPIS) + "</tr>")
        table_csv = [["method", "episodes"] + [k for k, _ in KPIS]]
        for n in names:
            r = groups[n]
            cells = []
            for k, _ in KPIS:
                v = np.array([float(x[k]) for x in r])
                cells.append(f"{v.mean():.2f} &plusmn; {v.std():.2f}")
            html.append(f"<tr><td>{n}</td><td>{len(r)}</td>" + "".join(f"<td>{c}</td>" for c in cells) + "</tr>")
            table_csv.append([n, len(r)] + [f"{np.mean([float(x[k]) for x in r]):.3f}" for k, _ in KPIS])
        html.append("</table>")
        with open("results_table.csv", "w", newline="") as f:
            csv.writer(f).writerows(table_csv)
        html.append("<h2>Method comparison</h2>")
        for k, title in KPIS:
            fig, ax = plt.subplots(figsize=(7, 3.2))
            means = [np.mean([float(x[k]) for x in groups[n]]) for n in names]
            stds = [np.std([float(x[k]) for x in groups[n]]) for n in names]
            ax.bar(names, means, yerr=stds, capsize=4, color="#4c78a8")
            ax.set_title(title, fontsize=10)
            ax.grid(axis="y", alpha=.3)
            html.append(f"<img src='data:image/png;base64,{_png(fig)}'>")
    else:
        html.append("<p>No evaluation results found yet. Run the evaluate and train scripts first.</p>")

    logs = [p for p in sorted(glob.glob("runs/*/train_log.csv")) if "probe" not in p]
    if logs:
        html.append("<h2>Training curves</h2>")
        for key, title in (("deliveries", "Deliveries per episode (training)"),
                           ("collisions", "Collisions per episode (training)")):
            fig, ax = plt.subplots(figsize=(7, 3.4))
            for p in logs:
                rows = _read(p)
                ax.plot([float(r["steps"]) for r in rows], [float(r[key]) for r in rows],
                        label=os.path.basename(os.path.dirname(p)), lw=1.4)
            ax.set_xlabel("environment steps")
            ax.set_title(title, fontsize=10)
            ax.legend(fontsize=7)
            ax.grid(alpha=.3)
            html.append(f"<img src='data:image/png;base64,{_png(fig)}'>")

    if os.path.exists("results/drift/drift_log.csv"):
        rows = _read("results/drift/drift_log.csv")
        alerts = json.load(open("results/drift/alerts.json"))
        html.append("<h2>Monitoring and drift detection</h2>")
        fig, ax = plt.subplots(figsize=(8, 3.4))
        ax.plot([int(r["episode"]) for r in rows], [float(r["throughput"]) for r in rows], marker=".")
        for al in alerts:
            ax.axvline(al["episode"], color="#d62728", ls="--", alpha=.7)
            ax.text(al["episode"], ax.get_ylim()[1], al["type"], rotation=90, va="top", fontsize=7, color="#d62728")
        ax.set_xlabel("episode")
        ax.set_ylabel("throughput")
        ax.grid(alpha=.3)
        html.append(f"<img src='data:image/png;base64,{_png(fig)}'><ul>")
        html += [f"<li>episode {al['episode']}: <b>{al['type']}</b> ({al['detail']})</li>" for al in alerts]
        html.append("</ul>")
    html.append("</body></html>")
    open(a.out, "w").write("\n".join(html))
    print("wrote", a.out)


if __name__ == "__main__":
    main()
