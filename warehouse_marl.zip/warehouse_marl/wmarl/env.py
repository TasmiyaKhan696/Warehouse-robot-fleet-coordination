"""Thin MARL wrapper around rware.Warehouse with versioned layouts, reward shaping,
extra observation features, and the project's evaluation metrics."""
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
from rware.warehouse import Warehouse, RewardType, Action, Direction, _LAYER_SHELFS
from . import nav
import warnings
warnings.filterwarnings("ignore", message=".*precision lowered.*")
warnings.filterwarnings("ignore", message=".*reward returned by.*")

LAYOUT_DIR = Path(__file__).resolve().parent.parent / "layouts"
PRESETS = {"tiny": (1, 3), "small": (2, 3), "medium": (2, 5), "large": (3, 5)}
_DELTA = {Direction.UP: (0, -1), Direction.DOWN: (0, 1),
          Direction.LEFT: (-1, 0), Direction.RIGHT: (1, 0)}


@dataclass
class EnvConfig:
    layout: str = "compact_v1"      # file in layouts/ (without .txt) or a preset name
    n_agents: int = 4
    request_queue_size: int = 0     # 0 means "same as n_agents"
    max_steps: int = 500
    sensor_range: int = 1
    shaping: float = 0.1            # scale of potential based shaping, 0 disables
    stage_bonus: float = 0.5        # bonus for picking a requested shelf / returning it after delivery
    collision_penalty: float = 0.1  # penalty per robot involved in a collision
    extra_obs: bool = True          # append target direction and stage features
    auto_load: bool = True          # pick up requested shelves / drop returned ones automatically

    def key(self):
        d = asdict(self)
        return "|".join(f"{k}={v}" for k, v in sorted(d.items()))


class WarehouseMARL:

    def __init__(self, cfg: EnvConfig, seed: int = 0):
        self.cfg = cfg
        q = cfg.request_queue_size or cfg.n_agents
        kw = dict(column_height=8, shelf_rows=1, shelf_columns=1, n_agents=cfg.n_agents,
                  msg_bits=0, sensor_range=cfg.sensor_range, request_queue_size=q,
                  max_inactivity_steps=None, max_steps=cfg.max_steps,
                  reward_type=RewardType.GLOBAL, normalised_coordinates=True)
        path = LAYOUT_DIR / f"{cfg.layout}.txt"
        if path.exists():
            kw["layout"] = path.read_text()
        elif cfg.layout in PRESETS:
            kw["shelf_rows"], kw["shelf_columns"] = PRESETS[cfg.layout]
        else:
            raise ValueError(f"Unknown layout {cfg.layout}")
        self.u = Warehouse(**kw)
        self.n_agents = cfg.n_agents
        self.n_actions = 4 if cfg.auto_load else 5   # auto_load removes the TOGGLE action
        self.seed = seed
        o, _ = self.u.reset(seed=seed)
        self.base_obs_dim = len(o[0])
        self.extra_dim = 7 if cfg.extra_obs else 0
        self.obs_dim = self.base_obs_dim + self.extra_dim
        self.state_dim = self.obs_dim * self.n_agents
        self.grid_h, self.grid_w = self.u.grid_size

    # ---- observations -------------------------------------------------
    def _build_obs(self, raw, tp):
        obs = np.stack([np.asarray(o, dtype=np.float32) for o in raw])
        if not self.cfg.extra_obs:
            return obs
        tgt, stage, _ = tp
        ex = np.zeros((self.n_agents, 7), dtype=np.float32)
        for i, a in enumerate(self.u.agents):
            dx, dy = tgt[i, 0] - a.x, tgt[i, 1] - a.y
            vx, vy = _DELTA[a.dir]
            ex[i, 0] = dx / self.grid_w
            ex[i, 1] = dy / self.grid_h
            ex[i, 2] = (dx * vx + dy * vy) / max(self.grid_w, self.grid_h)     # target ahead (+) / behind (-)
            ex[i, 3] = (-dx * vy + dy * vx) / max(self.grid_w, self.grid_h)    # target to the right (+) / left (-)
            ex[i, 4 + stage[i]] = 1.0
        return np.concatenate([obs, ex], 1)

    def global_state(self, obs):
        return obs.reshape(-1)

    # ---- episode control ----------------------------------------------
    def reset(self, seed=None):
        raw, _ = self.u.reset(seed=seed)
        self.t = 0
        self.stats = dict(deliveries=0, blocked=0, collisions=0, active=0,
                          carry=0, steps=0, ret=0.0)
        self._delivered = np.zeros(self.n_agents, dtype=bool)
        tp = nav.targets_and_potentials(self.u, delivered=self._delivered)
        self._stage, self._phi = tp[1], tp[2]
        return self._build_obs(raw, tp)

    def step(self, actions):
        u = self.u
        actions = [int(a) for a in actions]
        if self.cfg.auto_load:
            req_ids = {s.id for s in nav.free_requests(u)}
            for i, a in enumerate(u.agents):
                sid = u.grid[_LAYER_SHELFS, a.y, a.x]
                if a.carrying_shelf is None and sid in req_ids:
                    actions[i] = Action.TOGGLE_LOAD.value            # pick up the requested shelf
                elif (a.carrying_shelf is not None and not u.highways[a.y, a.x]
                      and self._stage[i] == nav.STAGE_RETURN):
                    actions[i] = Action.TOGGLE_LOAD.value            # drop the delivered shelf in a free slot
                elif actions[i] == Action.TOGGLE_LOAD.value:
                    actions[i] = Action.NOOP.value
        pre = [(a.x, a.y, a.dir) for a in u.agents]
        targets = []
        for (x, y, d), act in zip(pre, actions):
            if act == Action.FORWARD.value:
                dx, dy = _DELTA[d]
                tx = min(max(x + dx, 0), self.grid_w - 1)
                ty = min(max(y + dy, 0), self.grid_h - 1)
                targets.append((tx, ty))
            else:
                targets.append((x, y))
        raw, base_r, done, trunc, _ = u.step(actions)
        done = bool(done or trunc)
        post = [(a.x, a.y) for a in u.agents]

        coll = np.zeros(self.n_agents)
        blocked = 0
        for i, act in enumerate(actions):
            if act != Action.FORWARD.value:
                continue
            if post[i] != (pre[i][0], pre[i][1]) or targets[i] == (pre[i][0], pre[i][1]):
                continue
            blocked += 1          # wanted to move but could not (robot, shelf or conflict)
            for j in range(self.n_agents):
                if j == i:
                    continue
                if (pre[j][0], pre[j][1]) == targets[i] or \
                   (actions[j] == Action.FORWARD.value and targets[j] == targets[i]):
                    coll[i] = 1.0
                    break

        rewards = np.array(base_r, dtype=np.float32)
        delivered = int(round(float(base_r[0]))) if len(base_r) else 0
        rewards -= self.cfg.collision_penalty * coll.astype(np.float32)

        # a robot that was delivering and now holds a shelf nobody requested just delivered it
        for i, a in enumerate(u.agents):
            if self._stage[i] == nav.STAGE_DELIVER and a.carrying_shelf is not None \
                    and a.carrying_shelf not in u.request_queue:
                self._delivered[i] = True
        tp = nav.targets_and_potentials(u, delivered=self._delivered)
        stage_new, phi_new = tp[1], tp[2]
        if self.cfg.shaping > 0:
            for i in range(self.n_agents):
                # skip the jump when a finished return trip starts a new task
                if not (self._stage[i] == nav.STAGE_RETURN and stage_new[i] == nav.STAGE_SEEK):
                    rewards[i] += self.cfg.shaping * (0.99 * phi_new[i] - self._phi[i])
        if self.cfg.stage_bonus > 0:
            for i in range(self.n_agents):
                old, new = self._stage[i], stage_new[i]
                if old == nav.STAGE_SEEK and new == nav.STAGE_DELIVER:
                    rewards[i] += self.cfg.stage_bonus      # picked a requested shelf
                elif old == nav.STAGE_DELIVER and new == nav.STAGE_SEEK:
                    rewards[i] -= self.cfg.stage_bonus      # put it back undelivered (cancels the bonus)
                elif old == nav.STAGE_RETURN and new == nav.STAGE_SEEK:
                    rewards[i] += self.cfg.stage_bonus      # returned the shelf after a real delivery
        for i, a in enumerate(u.agents):
            if a.carrying_shelf is None:
                self._delivered[i] = False
        self._phi, self._stage = phi_new, stage_new

        s = self.stats
        s["deliveries"] += delivered
        s["blocked"] += blocked
        s["collisions"] += int(coll.sum())          # robot-level collision events
        s["active"] += sum(a != Action.NOOP.value for a in actions)
        s["carry"] += sum(a.carrying_shelf is not None for a in u.agents)
        s["steps"] += 1
        s["ret"] += float(rewards.mean())
        self.t += 1
        return self._build_obs(raw, tp), rewards, done, dict(delivered=delivered)

    def episode_metrics(self):
        s, n = self.stats, self.n_agents
        steps = max(1, s["steps"])
        d = s["deliveries"]
        return dict(
            deliveries=d,
            throughput=100.0 * d / steps,                       # deliveries per 100 steps
            collisions=s["collisions"],
            collision_rate=100.0 * s["collisions"] / steps,     # collision events per 100 steps
            blocked_moves=s["blocked"],
            steps_per_delivery=(steps / d) if d else float(steps),
            utilization=s["active"] / (steps * n),              # share of non idle robot steps
            carry_share=s["carry"] / (steps * n),
            efficiency=100.0 * d / max(1, s["active"]),         # deliveries per 100 active robot steps
            shaped_return=s["ret"],
        )

    def render_rgb(self):
        return self.u.render(mode="rgb_array")

    def close(self):
        self.u.close()


def make_env(**kw):
    seed = kw.pop("seed", 0)
    return WarehouseMARL(EnvConfig(**kw), seed=seed)
