"""IPPO and MAPPO (shared parameters, agent id one-hot).
ippo : critic sees only the robot's own observation.
mappo: critic sees the concatenated observations of all robots (CTDE).
Single agent PPO is ippo with n_agents=1."""
import time
import numpy as np
import torch
import torch.nn as nn
from torch.distributions import Categorical
from .vec import VecEnv


def mlp(i, o, h=128, last_gain=1.0):
    def lin(a, b, g):
        l = nn.Linear(a, b)
        nn.init.orthogonal_(l.weight, g)
        nn.init.zeros_(l.bias)
        return l
    return nn.Sequential(lin(i, h, 2 ** 0.5), nn.Tanh(), lin(h, h, 2 ** 0.5), nn.Tanh(), lin(h, o, last_gain))


class ActorCritic(nn.Module):
    def __init__(self, algo, n_agents, obs_dim, state_dim, n_actions, hidden=128):
        super().__init__()
        self.algo, self.n = algo, n_agents
        self.actor = mlp(obs_dim + n_agents, n_actions, hidden, 0.01)
        cin = (state_dim if algo == "mappo" else obs_dim) + n_agents
        self.critic = mlp(cin, 1, hidden, 1.0)
        self.register_buffer("eye", torch.eye(n_agents))

    def _ids(self, lead):
        return self.eye.expand(*lead, self.n, self.n)

    def logits(self, obs):                       # obs (..., N, od)
        lead = obs.shape[:-2]
        return self.actor(torch.cat([obs, self._ids(lead)], -1))

    def value(self, obs):
        lead = obs.shape[:-2]
        if self.algo == "mappo":
            st = obs.reshape(*lead, 1, -1).expand(*lead, self.n, -1)
            x = torch.cat([st, self._ids(lead)], -1)
        else:
            x = torch.cat([obs, self._ids(lead)], -1)
        return self.critic(x).squeeze(-1)


def train_ppo(cfg, algo="ippo", total_steps=500_000, n_envs=8, rollout=125, seed=0,
              lr=3e-4, gamma=0.99, lam=0.95, clip=0.2, ent=0.01, epochs=4, minibatches=4,
              procs=True, device="cpu", log_fn=print, log_every=5):
    torch.manual_seed(seed)
    np.random.seed(seed)
    venv = VecEnv(cfg, n_envs, seed, procs)
    N, od = venv.n_agents, venv.obs_dim
    net = ActorCritic(algo, N, od, venv.state_dim, venv.n_actions).to(device)
    opt = torch.optim.Adam(net.parameters(), lr=lr, eps=1e-5)
    T, E = rollout, n_envs
    steps_per_update = T * E
    n_updates = max(1, total_steps // steps_per_update)
    obs = torch.as_tensor(venv.reset(), device=device)
    history, ep_buf, t0, env_steps = [], [], time.time(), 0

    for upd in range(n_updates):
        for g in opt.param_groups:
            g["lr"] = lr * (1 - upd / n_updates)
        B_obs = torch.zeros(T, E, N, od, device=device)
        B_act = torch.zeros(T, E, N, dtype=torch.long, device=device)
        B_lp = torch.zeros(T, E, N, device=device)
        B_val = torch.zeros(T, E, N, device=device)
        B_rew = torch.zeros(T, E, N, device=device)
        B_done = torch.zeros(T, E, device=device)
        B_fv = torch.zeros(T, E, N, device=device)
        for t in range(T):
            with torch.no_grad():
                dist = Categorical(logits=net.logits(obs))
                a = dist.sample()
                B_lp[t] = dist.log_prob(a)
                B_val[t] = net.value(obs)
            B_obs[t], B_act[t] = obs, a
            nobs, r, done, final, metrics = venv.step(a.cpu().numpy())
            B_rew[t] = torch.as_tensor(r, device=device)
            B_done[t] = torch.as_tensor(done, dtype=torch.float32, device=device)
            for e, fo in final.items():
                with torch.no_grad():
                    B_fv[t, e] = net.value(torch.as_tensor(fo, device=device)[None])[0]
                ep_buf.append(metrics[e])
            obs = torch.as_tensor(nobs, device=device)
            env_steps += E
        with torch.no_grad():
            last_v = net.value(obs)
        adv = torch.zeros_like(B_rew)
        g_next = torch.zeros(E, N, device=device)
        for t in reversed(range(T)):
            nextv = last_v if t == T - 1 else B_val[t + 1]
            d = B_done[t][:, None]
            nextv = torch.where(d > 0, B_fv[t], nextv)
            delta = B_rew[t] + gamma * nextv - B_val[t]
            g_next = delta + gamma * lam * (1 - d) * g_next
            adv[t] = g_next
        ret = adv + B_val

        f_obs = B_obs.reshape(T * E, N, od)
        f_act, f_lp = B_act.reshape(T * E, N), B_lp.reshape(T * E, N)
        f_adv, f_ret = adv.reshape(T * E, N), ret.reshape(T * E, N)
        f_adv = (f_adv - f_adv.mean()) / (f_adv.std() + 1e-8)
        idx = np.arange(T * E)
        mb = (T * E) // minibatches
        for _ in range(epochs):
            np.random.shuffle(idx)
            for k in range(minibatches):
                j = torch.as_tensor(idx[k * mb:(k + 1) * mb], device=device)
                dist = Categorical(logits=net.logits(f_obs[j]))
                lp = dist.log_prob(f_act[j])
                ratio = torch.exp(lp - f_lp[j])
                pl = -torch.min(ratio * f_adv[j], torch.clamp(ratio, 1 - clip, 1 + clip) * f_adv[j]).mean()
                vl = 0.5 * ((net.value(f_obs[j]) - f_ret[j]) ** 2).mean()
                loss = pl + 0.5 * vl - ent * dist.entropy().mean()
                opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(net.parameters(), 0.5)
                opt.step()

        if ep_buf and (upd % log_every == 0 or upd == n_updates - 1):
            row = {k: float(np.mean([m[k] for m in ep_buf])) for k in ep_buf[0]}
            row.update(steps=env_steps, episodes=len(ep_buf), seconds=time.time() - t0)
            history.append(row)
            log_fn(f"[{algo}] steps {env_steps:>8} deliveries {row['deliveries']:6.1f} "
                   f"coll {row['collisions']:6.1f} util {row['utilization']:.2f} "
                   f"({row['seconds']:.0f}s)")
            ep_buf = []
    venv.close()
    meta = dict(algo=algo, n_agents=N, obs_dim=od, state_dim=venv.state_dim, n_actions=venv.n_actions)
    return net, meta, history


class PPOPolicy:
    def __init__(self, net, name, deterministic=True):
        self.net, self.name, self.det = net.eval(), name, deterministic

    def reset(self):
        pass

    def act(self, env, obs):
        with torch.no_grad():
            lg = self.net.logits(torch.as_tensor(obs, dtype=torch.float32))
            if self.det:
                return lg.argmax(-1).numpy()
            return Categorical(logits=lg).sample().numpy()
