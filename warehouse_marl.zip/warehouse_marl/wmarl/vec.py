"""Small vectorised environment. Uses one subprocess per env when procs=True
(use this on Colab, it has 2 CPU cores), otherwise runs envs in the main process."""
import multiprocessing as mp
import numpy as np
from .env import WarehouseMARL, EnvConfig


def _worker(conn, cfg, seed):
    env = WarehouseMARL(cfg, seed=seed)
    ep = 0
    while True:
        cmd, data = conn.recv()
        if cmd == "reset":
            conn.send(env.reset(seed=seed + ep * 9973))
            ep += 1
        elif cmd == "step":
            obs, r, done, _ = env.step(data)
            final, metrics = None, None
            if done:
                final, metrics = obs, env.episode_metrics()
                obs = env.reset(seed=seed + ep * 9973)
                ep += 1
            conn.send((obs, r, done, final, metrics))
        elif cmd == "close":
            conn.close()
            break


class VecEnv:
    def __init__(self, cfg: EnvConfig, n_envs=8, seed=0, procs=True):
        self.cfg, self.n_envs, self.procs = cfg, n_envs, procs
        probe = WarehouseMARL(cfg, seed=seed)
        self.n_agents, self.obs_dim, self.state_dim = probe.n_agents, probe.obs_dim, probe.state_dim
        self.n_actions = probe.n_actions
        if procs:
            ctx = mp.get_context("fork")
            self.conns, self.ps = [], []
            for i in range(n_envs):
                a, b = ctx.Pipe()
                p = ctx.Process(target=_worker, args=(b, cfg, seed + 1000 * i), daemon=True)
                p.start()
                self.conns.append(a)
                self.ps.append(p)
        else:
            self.envs = [WarehouseMARL(cfg, seed=seed + 1000 * i) for i in range(n_envs)]
            self.eps = [0] * n_envs
            self.seeds = [seed + 1000 * i for i in range(n_envs)]

    def reset(self):
        if self.procs:
            for c in self.conns:
                c.send(("reset", None))
            return np.stack([c.recv() for c in self.conns])
        out = []
        for i, e in enumerate(self.envs):
            out.append(e.reset(seed=self.seeds[i] + self.eps[i] * 9973))
            self.eps[i] += 1
        return np.stack(out)

    def step(self, actions):
        """actions (E,N). Returns obs (E,N,od), rew (E,N), done (E,), final {e: obs}, metrics {e: dict}."""
        if self.procs:
            for c, a in zip(self.conns, actions):
                c.send(("step", a))
            res = [c.recv() for c in self.conns]
        else:
            res = []
            for i, (e, a) in enumerate(zip(self.envs, actions)):
                obs, r, done, _ = e.step(a)
                final, metrics = None, None
                if done:
                    final, metrics = obs, e.episode_metrics()
                    obs = e.reset(seed=self.seeds[i] + self.eps[i] * 9973)
                    self.eps[i] += 1
                res.append((obs, r, done, final, metrics))
        obs = np.stack([r[0] for r in res])
        rew = np.stack([r[1] for r in res]).astype(np.float32)
        done = np.array([r[2] for r in res])
        final = {i: r[3] for i, r in enumerate(res) if r[2]}
        metrics = {i: r[4] for i, r in enumerate(res) if r[2]}
        return obs, rew, done, final, metrics

    def close(self):
        if self.procs:
            for c in self.conns:
                try:
                    c.send(("close", None))
                except Exception:
                    pass
