"""QMIX with parameter sharing (agent id one-hot), feed-forward agent networks,
monotonic mixing network conditioned on the global state (concatenated observations)."""
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from .vec import VecEnv


class AgentQ(nn.Module):
    def __init__(self, n_agents, obs_dim, n_actions, hidden=128):
        super().__init__()
        self.n = n_agents
        self.net = nn.Sequential(nn.Linear(obs_dim + n_agents, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, n_actions))
        self.register_buffer("eye", torch.eye(n_agents))

    def forward(self, obs):                      # (B, N, od)
        ids = self.eye.expand(obs.shape[0], self.n, self.n)
        return self.net(torch.cat([obs, ids], -1))


class Mixer(nn.Module):
    def __init__(self, n_agents, state_dim, embed=32, hyper=64):
        super().__init__()
        self.n, self.e = n_agents, embed
        self.w1 = nn.Sequential(nn.Linear(state_dim, hyper), nn.ReLU(), nn.Linear(hyper, n_agents * embed))
        self.b1 = nn.Linear(state_dim, embed)
        self.w2 = nn.Sequential(nn.Linear(state_dim, hyper), nn.ReLU(), nn.Linear(hyper, embed))
        self.b2 = nn.Sequential(nn.Linear(state_dim, embed), nn.ReLU(), nn.Linear(embed, 1))

    def forward(self, q, state):                 # q (B,N), state (B,S)
        B = q.shape[0]
        w1 = torch.abs(self.w1(state)).view(B, self.n, self.e)
        h = F.elu(torch.bmm(q.unsqueeze(1), w1) + self.b1(state).unsqueeze(1))
        w2 = torch.abs(self.w2(state)).view(B, self.e, 1)
        return (torch.bmm(h, w2) + self.b2(state).unsqueeze(1)).view(B)


def train_qmix(cfg, total_steps=500_000, n_envs=8, seed=0, lr=5e-4, gamma=0.99,
               batch=256, buffer=200_000, warmup=5_000, updates_per_step=4,
               target_every=200, eps_start=1.0, eps_end=0.05, eps_frac=0.3,
               procs=True, device="cpu", log_fn=print, log_every=2_000):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    venv = VecEnv(cfg, n_envs, seed, procs)
    N, od, sd, A = venv.n_agents, venv.obs_dim, venv.state_dim, venv.n_actions
    q, qt = AgentQ(N, od, A).to(device), AgentQ(N, od, A).to(device)
    m, mt = Mixer(N, sd).to(device), Mixer(N, sd).to(device)
    qt.load_state_dict(q.state_dict())
    mt.load_state_dict(m.state_dict())
    opt = torch.optim.Adam(list(q.parameters()) + list(m.parameters()), lr=lr)
    cap = buffer
    O = np.zeros((cap, N, od), np.float32)
    O2 = np.zeros((cap, N, od), np.float32)
    ACT = np.zeros((cap, N), np.int64)
    R = np.zeros(cap, np.float32)
    ptr = size = 0
    obs = venv.reset()
    history, ep_buf, t0, env_steps, n_upd, last_log = [], [], time.time(), 0, 0, 0

    while env_steps < total_steps:
        eps = max(eps_end, eps_start - (eps_start - eps_end) * env_steps / (eps_frac * total_steps))
        with torch.no_grad():
            qv = q(torch.as_tensor(obs.reshape(-1, N, od), device=device))
            greedy = qv.argmax(-1).cpu().numpy()
        rand = rng.integers(0, A, size=greedy.shape)
        act = np.where(rng.random(greedy.shape) < eps, rand, greedy)
        nobs, r, done, final, metrics = venv.step(act)
        next_for_buffer = nobs.copy()
        for e, fo in final.items():
            next_for_buffer[e] = fo
            ep_buf.append(metrics[e])
        for e in range(n_envs):
            O[ptr], O2[ptr], ACT[ptr], R[ptr] = obs[e], next_for_buffer[e], act[e], r[e].mean()
            ptr = (ptr + 1) % cap
            size = min(size + 1, cap)
        obs = nobs
        env_steps += n_envs
        if size >= warmup:
            for _ in range(updates_per_step):
                j = rng.integers(0, size, batch)
                o = torch.as_tensor(O[j], device=device)
                o2 = torch.as_tensor(O2[j], device=device)
                a = torch.as_tensor(ACT[j], device=device)
                rew = torch.as_tensor(R[j], device=device)
                qa = q(o).gather(-1, a.unsqueeze(-1)).squeeze(-1)
                qtot = m(qa, o.reshape(batch, -1))
                with torch.no_grad():
                    best = q(o2).argmax(-1, keepdim=True)          # double Q
                    qn = qt(o2).gather(-1, best).squeeze(-1)
                    target = rew + gamma * mt(qn, o2.reshape(batch, -1))   # time limit only, always bootstrap
                loss = F.smooth_l1_loss(qtot, target)
                opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(list(q.parameters()) + list(m.parameters()), 10)
                opt.step()
                n_upd += 1
                if n_upd % target_every == 0:
                    qt.load_state_dict(q.state_dict())
                    mt.load_state_dict(m.state_dict())
        if ep_buf and env_steps - last_log >= log_every:
            last_log = env_steps
            row = {k: float(np.mean([x[k] for x in ep_buf])) for k in ep_buf[0]}
            row.update(steps=env_steps, episodes=len(ep_buf), seconds=time.time() - t0, epsilon=eps)
            history.append(row)
            log_fn(f"[qmix] steps {env_steps:>8} deliveries {row['deliveries']:6.1f} "
                   f"coll {row['collisions']:6.1f} eps {eps:.2f} ({row['seconds']:.0f}s)")
            ep_buf = []
    venv.close()
    meta = dict(algo="qmix", n_agents=N, obs_dim=od, state_dim=sd, n_actions=A)
    return q, meta, history


class QmixPolicy:
    name = "qmix"

    def __init__(self, q, eps=0.02):
        self.q, self.eps = q.eval(), eps      # small epsilon breaks deadlocks between robots
        self.rng = np.random.default_rng(0)

    def reset(self):
        pass

    def act(self, env, obs):
        with torch.no_grad():
            a = self.q(torch.as_tensor(obs, dtype=torch.float32)[None])[0].argmax(-1).numpy()
        rand = self.rng.integers(0, self.q.net[-1].out_features, size=a.shape)
        return np.where(self.rng.random(a.shape) < self.eps, rand, a)
