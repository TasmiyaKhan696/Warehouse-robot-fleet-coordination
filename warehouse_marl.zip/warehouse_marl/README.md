# Autonomous warehouse robot fleet coordination with MARL

This project trains a fleet of warehouse robots to pick requested shelves, deliver them to goal cells and
return them, while avoiding each other. It compares IPPO, MAPPO and QMIX against random and greedy
baselines on the open-source RWARE (robotic warehouse) simulator. It covers the pieces named in the project
deck: layouts under version control, reward shaping with a collision penalty, throughput, collision rate,
task completion time, utilization and coordination efficiency metrics, a dashboard with drift detection, and a
live demo.

## What is in the folder

    layouts/            warehouse grids as text files (x shelf, g goal, . floor). Version these in git.
    wmarl/env.py        environment wrapper: observations, reward shaping, collision metric, KPIs
    wmarl/nav.py        distances, BFS path planning, stage logic (shared by shaping and greedy)
    wmarl/baselines.py  random and greedy policies
    wmarl/ppo.py        IPPO, MAPPO (and single agent PPO as IPPO with one robot)
    wmarl/qmix.py       QMIX with a monotonic mixing network
    wmarl/vec.py        parallel environments (one process per environment)
    wmarl/train.py      train one run, save model, training log and a final evaluation
    wmarl/evaluate.py   evaluate any policy on identical seeds, save per episode metrics
    wmarl/monitor.py    drift and KPI threshold monitor
    wmarl/drift_demo.py runs a changing stream through the monitor
    wmarl/dashboard.py  builds dashboard.html from all results
    wmarl/demo.py       saves a GIF (or opens a live window) of a policy running
    run_all.sh          the whole experiment pipeline in one script

## Setup (laptop or Colab)

    pip install rware gymnasium numpy matplotlib pillow torch

On Colab, also run this once so the demo can render without a screen:

    apt-get update && apt-get install -y xvfb libgl1 libglu1-mesa

Run every command from the project root (the folder that contains `wmarl/`). On Colab, upload the zip, unzip it,
then `%cd warehouse_marl` and run commands with `!` in front. For GPU training add `--device cuda`; the networks
are small, so the CPU is usually the bottleneck (the simulator), not the GPU.

## Run order

1. Check the environment and baselines (a few minutes):

       python -m wmarl.evaluate --policy random --episodes 30 --out results/random
       python -m wmarl.evaluate --policy greedy --episodes 30 --out results/greedy

2. Train. Start small to check things work, then scale up:

       python -m wmarl.train --algo ippo --steps 200000 --name test_ippo
       python -m wmarl.train --algo ippo  --steps 1000000 --seed 0 --name ippo_s0
       python -m wmarl.train --algo mappo --steps 1000000 --seed 0 --name mappo_s0
       python -m wmarl.train --algo qmix  --steps 1000000 --seed 0 --name qmix_s0

   or run everything (3 seeds, all algorithms, baselines, dashboard): `bash run_all.sh`.
   Override the budget with environment variables, e.g. `STEPS=500000 SEEDS="0 1" bash run_all.sh`.

3. Monitoring demo and dashboard:

       python -m wmarl.drift_demo --out results/drift
       python -m wmarl.dashboard --out dashboard.html

4. Demo GIFs for the presentation:

       xvfb-run -a python -m wmarl.demo --policy greedy --gif demo_greedy.gif
       xvfb-run -a python -m wmarl.demo --policy run:runs/mappo_s0 --gif demo_mappo.gif

## How the pieces work

**Environment.** RWARE gives a grid with shelves, goals and robots. Robots turn, move forward, and carry
shelves. A shelf that reaches a goal while it is on the request list counts as one delivery, and the robot then
has to put the shelf back in a free shelf slot. Each robot sees a small window around itself. This wrapper adds
seven features per robot (direction to its current target in world coordinates and in the robot's own frame,
plus a stage flag: seeking, delivering, returning) so the networks do not have to discover navigation from a
3x3 view alone.

**auto_load (important assumption).** By default robots pick up a requested shelf automatically when they
stand on it and drop a delivered shelf automatically when they reach a free slot, so the action space is
four moves (stay, forward, left, right). I made this choice because with the raw pick and drop action the
policy did not learn in a student budget (my 140k step test produced zero deliveries). Task allocation and collision
avoidance, the scope in your deck, remain fully learned. State this assumption in the report. To use raw RWARE
actions, set `auto_load=False` in `EnvConfig` (expect to need many more steps) and note that results are then
comparable to published RWARE numbers only if the layout and rules also match.

**Reward.** Team delivery reward from RWARE (every robot gets +1 per delivery), minus `collision_penalty`
(default 0.1) for each robot involved in a collision, plus potential based shaping from the remaining distance of
the pick, deliver, return cycle (`shaping`, default 0.1), plus a small stage bonus for picking a requested shelf
and returning it after a real delivery (`stage_bonus`, default 0.5). The bonus is cancelled if a requested shelf
is put back undelivered. Shaping is used only for training: all reported KPIs come from deliveries and collisions,
never from the shaped reward. An earlier version of the shaping was exploitable (robots collected shaping reward
without delivering anything), so if you change `nav.py` or the shaping, always check that deliveries rise along
with the shaped return in `train_log.csv`.

**Algorithms.** All three share one network across robots and add a one-hot robot id to the input.
IPPO uses a critic on each robot's own observation. MAPPO uses a critic on the concatenation of all
observations (centralized training, decentralized execution). QMIX trains per robot Q networks and a mixing
network conditioned on the same concatenated state, with double Q targets. Single agent PPO is IPPO with one
robot and one request (`--algo ppo --queue 1`). Time limits are treated as truncation, not as a terminal
state.

**KPIs (per episode of 500 steps).**

    throughput           deliveries per 100 steps
    collision_rate       robot collision events per 100 steps (a robot tried to move into a cell
                         occupied by, or targeted by, another robot and the move failed)
    blocked_moves        all failed forward moves (robots, shelves, conflicts)
    steps_per_delivery   task completion time (500 if nothing was delivered)
    utilization          share of robot steps that were not "stay"
    efficiency           deliveries per 100 active robot steps (coordination efficiency)

Policies are evaluated on the same fixed seeds. PPO policies are evaluated by sampling actions, as in training,
because the argmax policy tends to deadlock with two robots facing each other. QMIX uses epsilon 0.02 for the
same reason.

**Monitoring.** `DriftMonitor` raises an alert when (a) the layout, fleet size or demand setting changes, (b) the
rolling average throughput differs from the reference window by more than 3 standard errors for three
consecutive episodes (a sustained shift), or (c) the rolling average falls below an agreed KPI threshold. The
demo runs the greedy policy through a stream with a hidden demand drop and then a layout and fleet change. A
trained network is tied to the fleet size and layout it was trained on, so changing those means retraining; that is
exactly what the alert is for.

## What to expect

Measured on a single CPU core with the default settings (compact_v1, 4 robots, 500 steps per episode):

    random   about 1.6 deliveries per episode, many collisions
    greedy   about 63 deliveries per episode, about 12 collision events
    IPPO     about 17 deliveries per episode after only 200k steps (a short test run, one seed)

    QMIX     ran end to end, but a 60k step test was still at random level (about 1.5 deliveries)

I did not train QMIX long enough to know where it ends up. Watch its training curve: if deliveries are not rising
by around 300k to 500k steps, tune the learning rate, `eps_frac` and `updates_per_step` in `wmarl/qmix.py`.

Greedy is a strong hand written baseline (shortest paths, unique target assignment). Learned policies may or may
not beat it within your budget. Either outcome is a valid finding, as long as you report it with several seeds and
discuss why (the decentralized policies see only a small window, rewards are sparse, training is short). Things
worth tuning for the research part of the deck: `collision_penalty` (trade throughput for safety), `shaping`,
`stage_bonus`, learning rate, and total steps. Training speed was about 850 environment steps per second per core,
so 1M steps is roughly 20 minutes of PPO on one core; QMIX is slower because of its gradient updates.

## Report checklist (map to your PLM stages)

Problem definition: README sections above. Data preparation: layouts and the configuration saved in each
`runs/<name>/config.json`. Model training: `runs/<name>/train_log.csv`. Evaluation: `results_table.csv` and
`dashboard.html` (compare to random and greedy, report mean and standard deviation over seeds). Deployment:
the GIF demo (simulation only, no deployment claim). Monitoring: the drift demo and alerts. Ethics: state
that this is a simulation study, report collisions next to throughput, and keep the per episode logs.
